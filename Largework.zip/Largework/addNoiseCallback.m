function addNoiseCallback(~, ~)
    global img noisyImg; % 原始图像和加噪图像

    % 检查是否加载了图像
    if isempty(img)
        errordlg('请先加载图像！', '错误');
        return;
    end

    % 用户输入噪声参数
    prompt = {'输入噪声类型（gaussian/salt & pepper）：', '输入噪声方差（0-1）:'};
    dlgTitle = '添加噪声';
    dims = [1 50];
    defInput = {'gaussian', '0.01'};
    answer = inputdlg(prompt, dlgTitle, dims, defInput);

    if isempty(answer)
        return; % 用户取消操作
    end

    noiseType = answer{1};
    noiseVar = str2double(answer{2});

    % 添加噪声
    if strcmpi(noiseType, 'gaussian')
        noisyImg = imnoise(img, 'gaussian', 0, noiseVar);
    elseif strcmpi(noiseType, 'salt & pepper')
        noisyImg = imnoise(img, 'salt & pepper', noiseVar);
    else
        errordlg('无效的噪声类型！', '错误');
        return;
    end

    % 显示加噪后的图像
    figure;
    subplot(1, 2, 1); imshow(img); title('原始图像');
    subplot(1, 2, 2); imshow(noisyImg); title('加噪图像');
end
