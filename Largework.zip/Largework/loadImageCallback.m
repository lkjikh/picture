function loadImageCallback(~, ~)
    global img;
    [filename, pathname] = uigetfile({'*.jpg;*.png;*.bmp'}, '选择图像');
    if isequal(filename, 0)
        return;
    end
    img = imread(fullfile(pathname, filename));
    axes(findobj('Type', 'axes'));
    imshow(img);
    title('加载的图像');
end
