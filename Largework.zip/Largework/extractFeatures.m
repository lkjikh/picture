function extractFeatures(~, ~)
    % 1. 图像加载
    global img
    figure; 
    subplot(2,2,1)
    imshow(img); title('原始图像');

    % 2. 图像灰度化（如果是彩色图像）
    if size(img, 3) == 3
        grayImg = rgb2gray(img);
    else
        grayImg = img;
    end
    subplot(2,2,2)
    imshow(grayImg); title('灰度图像');

    % 3. 目标提取
    % 使用 Otsu 方法分割并形态学处理
    smoothImg = imgaussfilt(grayImg, 2); % 高斯滤波
    level = graythresh(smoothImg); % Otsu 阈值
    binaryImg = imbinarize(smoothImg, level); % 二值化
    cleanImg = imopen(binaryImg, strel('disk', 3)); % 开运算去噪
    filledImg = imfill(cleanImg, 'holes'); % 填充孔洞
    subplot(2,2,3)
    imshow(filledImg); title('提取目标的二值图像');

    % 提取目标区域
    labeledImage = bwlabel(filledImg); % 连通区域标记
    stats = regionprops(labeledImage, 'BoundingBox', 'Area'); % 获取属性
    largestArea = max([stats.Area]); % 找到最大区域
    largestRegion = stats([stats.Area] == largestArea); % 提取最大区域
    targetBoundingBox = largestRegion.BoundingBox; % 获取目标边界框
    targetImg = imcrop(grayImg, targetBoundingBox); % 裁剪目标区域
   subplot(2,2,4)
   imshow(targetImg, []); title('目标区域');

    % 4. LBP 特征提取
    lbpOriginal = extractLBPFeatures(grayImg); % 原始图像 LBP 特征
    lbpTarget = extractLBPFeatures(targetImg); % 目标区域 LBP 特征
    disp('原始图像 LBP 特征:');
    disp(lbpOriginal);
    disp('目标区域 LBP 特征:');
    disp(lbpTarget);

    % 可视化 LBP 特征
    figure; 
    subplot(1, 2, 1);
    plot(lbpOriginal); title('原始图像 LBP 特征');
    subplot(1, 2, 2);
    plot(lbpTarget); title('目标区域 LBP 特征');

    % 5. HOG 特征提取
    [hogOriginal, visOriginal] = extractHOGFeatures(grayImg); % 原始图像 HOG 特征
    [hogTarget, visTarget] = extractHOGFeatures(targetImg); % 目标区域 HOG 特征
    disp('原始图像 HOG 特征:');
    disp(hogOriginal);
    disp('目标区域 HOG 特征:');
    disp(hogTarget);

    % 可视化 HOG 特征
    figure; 
    subplot(1, 2, 1);
    imshow(grayImg); hold on;
    plot(visOriginal); title('原始图像 HOG 特征');
    subplot(1, 2, 2);
    imshow(targetImg); hold on;
    plot(visTarget); title('目标区域 HOG 特征');
end
