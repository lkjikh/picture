function frequencyFilterCallback(~, ~)
    global noisyImg; % 使用加噪图像进行滤波
    noisyImg = rgb2gray(noisyImg);

    if isempty(noisyImg)
        errordlg('请先添加噪声！', '错误');
        return;
    end

    % 用户输入截止频率
    prompt = {'输入截止频率（0-1）：'};
    dlgTitle = '频域滤波';
    dims = [1 50];
    defInput = {'0.1'};
    answer = inputdlg(prompt, dlgTitle, dims, defInput);

    if isempty(answer)
        return;
    end

    cutoff = str2double(answer{1});

    % 图像转换为频域
    [M, N] = size(noisyImg); % 获取图像大小
    F = fftshift(fft2(double(noisyImg))); % 频域变换

    % 生成理想低通滤波器
    % 使用 meshgrid 并强制调整大小匹配
    [X, Y] = meshgrid(-floor(N/2):ceil(N/2)-1, -floor(M/2):ceil(M/2)-1); % 创建匹配网格
    D = sqrt(X.^2 + Y.^2); % 计算频率距离
    H = double(D <= cutoff * max(D(:))); % 理想低通滤波器

    % 确保滤波器大小匹配 F
    H = imresize(H, [M, N], 'nearest'); % 调整 H 的大小到 [M, N]

    % 应用滤波器
    G = F .* H; % 逐元素相乘，滤波

    % 逆傅里叶变换
    filteredImg = real(ifft2(ifftshift(G))); % 逆变换到空间域

    % 显示结果
    figure;
    subplot(1, 3, 1); imshow(noisyImg, []); title('加噪图像');
    subplot(1, 3, 2); imshow(log(1 + abs(F)), []); title('频谱');
    subplot(1, 3, 3); imshow(filteredImg, []); title('频域滤波后图像');
end
