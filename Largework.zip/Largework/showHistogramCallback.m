function showHistogramCallback(~, ~)
    global img;
    grayImg = rgb2gray(img);
    figure;
    imhist(grayImg);
    title('灰度直方图');
end

