function spatialFilterCallback(~, ~)
    global noisyImg; % 使用加噪图像进行滤波
    if isempty(noisyImg)
        errordlg('请先添加噪声！', '错误');
        return;
    end

    % 用户选择滤波类型
    filterType = questdlg('选择空间域滤波器：', '滤波选项', ...
                          '均值滤波', '中值滤波', '取消', '均值滤波');
    if strcmp(filterType, '取消') || isempty(filterType)
        return;
    end

    % 检查是否为彩色图像
    if size(noisyImg, 3) == 3
        noisyImgGray = rgb2gray(noisyImg); % 转换为灰度图像
    else
        noisyImgGray = noisyImg; % 已是灰度图像
    end

    % 应用滤波
    if strcmp(filterType, '均值滤波')
        filteredImg = imfilter(noisyImgGray, fspecial('average', [3 3]));
    elseif strcmp(filterType, '中值滤波')
        filteredImg = medfilt2(noisyImgGray);
    end

    % 显示结果
    figure;
    subplot(1, 2, 1); imshow(noisyImg); title('加噪图像');
    subplot(1, 2, 2); imshow(filteredImg); title(['滤波后图像（', filterType, '）']);
end
