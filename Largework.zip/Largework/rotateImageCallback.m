function rotateImageCallback(~, ~)
    global img;
    angle = inputdlg('请输入旋转角度：', '图像旋转');
    rotatedImg = imrotate(img, str2double(angle{1}));
    figure; imshow(rotatedImg); title(['旋转 ', angle{1}, '° 后的图像']);
end

function flipImageCallback(~, ~)
    global img;
    flippedImg = flip(img, 2); % 水平翻转
    figure; imshow(flippedImg); title('水平翻转后的图像');
end
