function edgeDetectionCallback(~, ~)
    global img;
    grayImg = rgb2gray(img);

    % Robert 算子
    robertsEdge = edge(grayImg, 'roberts');

    % Prewitt 算子
    prewittEdge = edge(grayImg, 'prewitt');

    % Sobel 算子
    sobelEdge = edge(grayImg, 'sobel');

    figure;
    subplot(1, 3, 1); imshow(robertsEdge); title('Robert 边缘检测');
    subplot(1, 3, 2); imshow(prewittEdge); title('Prewitt 边缘检测');
    subplot(1, 3, 3); imshow(sobelEdge); title('Sobel 边缘检测');
end
