function histogramEqualizationCallback(~, ~)
    global img;
    grayImg = rgb2gray(img);
    equalizedImg = histeq(grayImg);
    figure;
    subplot(1, 2, 1); imshow(grayImg); title('原始灰度图像');
    subplot(1, 2, 2); imshow(equalizedImg); title('均衡化图像');
end