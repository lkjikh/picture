function extractTarget(~, ~)
    global img
    figure; 
    subplot(2,3,1)
    imshow(img); title('原始图像');
    
    % 2. 图像灰度化（如果是彩色图像）
    if size(img, 3) == 3
        grayImg = rgb2gray(img);
    else
        grayImg = img;
    end
    subplot(2,3,2)
    imshow(grayImg); title('灰度图像');
    
    % 3. 噪声去除（使用高斯滤波）
    smoothImg = imgaussfilt(grayImg, 2); % 高斯滤波，标准差为2
    subplot(2,3,3)
    imshow(smoothImg); title('去噪图像');
    
    % 4. 阈值分割
    level = graythresh(smoothImg); % Otsu方法计算全局阈值
    binaryImg = imbinarize(smoothImg, level); % 二值化
    subplot(2,3,4)
    imshow(binaryImg); title('二值图像');
    
    % 5. 形态学操作（去除噪声，填充目标区域）
    cleanImg = imopen(binaryImg, strel('disk', 3)); % 开运算去噪
    filledImg = imfill(cleanImg, 'holes'); % 填充目标区域的空洞
    subplot(2,3,5)
    imshow(filledImg); title('形态学处理后图像');
    
    % 6. 提取目标轮廓（使用边缘检测）
    edges = edge(filledImg, 'Canny'); % Canny边缘检测
    subplot(2,3,6)
    imshow(edges); title('目标边缘');
    
    % 7. 标记连通区域（提取目标区域）
    [labeledImage, numObjects] = bwlabel(filledImg); % 连通区域标记
    stats = regionprops(labeledImage, 'BoundingBox', 'Area'); % 获取区域属性

    % 显示目标提取结果
    figure; imshow(img); title('目标提取结果');
    hold on;
    for i = 1:numObjects
        % 如果目标区域面积过小，则忽略（排除噪声）
        if stats(i).Area > 500 % 自定义面积阈值
            rectangle('Position', stats(i).BoundingBox, 'EdgeColor', 'r', 'LineWidth', 2);
        end
    end
    hold off;
    disp(['检测到的目标数量: ', num2str(numObjects)]);
end
