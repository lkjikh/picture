function flipImageCallback(~, ~)
    global img;
    flippedImg = flip(img, 2); % 水平翻转
    figure; imshow(flippedImg); title('水平翻转后的图像');
end