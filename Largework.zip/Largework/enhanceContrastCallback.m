function enhanceContrastCallback(~, ~)
    global img;
    grayImg = rgb2gray(img);

    % 线性变换
    linearEnhanced = imadjust(grayImg, stretchlim(grayImg), []);

    % 对数变换
    c = 1; logEnhanced = c * log(1 + double(grayImg));

    % 指数变换
    gamma = 2.2; expEnhanced = im2uint8(mat2gray(double(grayImg).^gamma));

    figure;
    subplot(2, 2, 1); imshow(grayImg); title('原始灰度图像');
    subplot(2, 2, 2); imshow(linearEnhanced); title('线性增强');
    subplot(2, 2, 3); imshow(mat2gray(logEnhanced)); title('对数变换');
    subplot(2, 2, 4); imshow(expEnhanced); title('指数变换');
end