function histogramMatchingCallback(~, ~)
    global img;

    targetImage = img;
    targetGray = rgb2gray(targetImage);

    % 当前图像的灰度化
    grayImg = rgb2gray(img);

    % 执行直方图配准
    matchedImage = imhistmatch(grayImg, targetGray);

    % 显示结果
    figure;
    subplot(1, 3, 1); imshow(grayImg); title('原始灰度图像');
    subplot(1, 3, 2); imshow(targetGray); title('目标图像灰度');
    subplot(1, 3, 3); imshow(matchedImage); title('直方图配准后的图像');
end
